import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AnalyticsPage } from './analytics.component';
import { IonicModule } from '@ionic/angular';

@NgModule({
  imports: [
    CommonModule,
    IonicModule,
    AnalyticsRoutingModule
  ],

  declarations: [ AnalyticsPage]
})
export class AnalyticsModule { }
