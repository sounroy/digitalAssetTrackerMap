import { Component, OnInit, OnDestroy } from '@angular/core';
import { IonItemSliding, LoadingController } from '@ionic/angular';
import { Subscription } from 'rxjs';

import { WatchListService } from './watchlist.service';
import { WatchItem } from './watch-item.model';

@Component({
  selector: 'app-watchlist',
  templateUrl: './watchlist.component.html',
  styleUrls: ['./watchlist.scss']
})
export class WatchListPage implements OnInit, OnDestroy {
  loadedwatchItems: WatchItem[];
  isLoading = false;
  private watchListSub: Subscription;

  constructor(
    private watchListService: WatchListService,
    private loadingCtrl: LoadingController
  ) {}

  ngOnInit() {
    this.watchListSub = this.watchListService.watchItems.subscribe(watchItems => {
      this.loadedwatchItems = watchItems;
    });
  }

  ionViewWillEnter() {
    this.isLoading = true;
    this.watchListService.fetchWatchItems().subscribe(() => {
      this.isLoading = false;
    });
  }

  onCancelWatch(watchItemId: string, slidingEl: IonItemSliding) {
    slidingEl.close();
    this.loadingCtrl.create({ message: 'Cancelling...' }).then(loadingEl => {
      loadingEl.present();
      this.watchListService.cancelWatch(watchItemId).subscribe(() => {
        loadingEl.dismiss();
      });
    });
  }

  ngOnDestroy() {
    if (this.watchListSub) {
      this.watchListSub.unsubscribe();
    }
  }
}
