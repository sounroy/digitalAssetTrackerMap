import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './auth/auth.guard';

const routes: Routes = [
  { path: '', redirectTo: 'auth', pathMatch: 'full' },
  { path: 'auth', loadChildren: './auth/auth.module#AuthPageModule' },
  {
    path: 'assets',
    loadChildren: './assets/assets.module#AssetsPageModule',
    canLoad: [AuthGuard] 
  },
  {
    path: 'analytics',
    loadChildren: './analytics/analytics.module#AnalyticsModule',
    canLoad: [AuthGuard] 
  }
  /*,
  {
    path: 'bookings',
    loadChildren: './statistics/statistics.module#StatisticsPageModule'
     canLoad: [AuthGuard] 
  }*/
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
