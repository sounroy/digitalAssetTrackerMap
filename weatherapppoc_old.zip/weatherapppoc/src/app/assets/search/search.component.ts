import { Component, OnInit } from '@angular/core';
import { MenuController } from '@ionic/angular';

import { AssetsService } from '../assets.service';
import { Asset } from '../asset.model';
import { SegmentChangeEventDetail } from '@ionic/core';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.scss']
})
export class SearchPage implements OnInit {
  loadedAssets: Asset[];
  staticLoadedAssets: Asset[];

  constructor(
    private assetsService: AssetsService,
    private menuCtrl: MenuController
  ) {}

  ngOnInit() {
    this.loadedAssets = this.assetsService.assets;
    this.staticLoadedAssets = this.loadedAssets.slice(1);
  }

  onOpenMenu() {
    this.menuCtrl.toggle();
  }

  onFilterChange(event: CustomEvent<SegmentChangeEventDetail>) {
    console.log(event.detail);
  }
}
