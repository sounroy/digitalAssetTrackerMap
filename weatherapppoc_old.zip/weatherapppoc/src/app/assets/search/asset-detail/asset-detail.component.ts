import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NavController, ModalController, ActionSheetController } from '@ionic/angular';

import { AssetsService } from '../../assets.service';
import { Asset } from '../../asset.model';
//import { CreateAssetComponent } from '../../../assets/create-asset/create-asset.component';

@Component({
  selector: 'app-asset-detail',
  templateUrl: './asset-detail.component.html',
  styleUrls: ['./asset-detail.scss']
})
export class AssetDetailPage implements OnInit {
  asset: Asset;

  constructor(
    private navCtrl: NavController,
    private route: ActivatedRoute,
    private placesService: AssetsService,
    private modalCtrl: ModalController,
    private actionSheetCtrl: ActionSheetController
  ) {}

  ngOnInit() {
    this.route.paramMap.subscribe(paramMap => {
      if (!paramMap.has('assetId')) {
        this.navCtrl.navigateBack('/assets/tabs/search');
        return;
      }
      this.asset = this.placesService.getAsset(paramMap.get('assetId'));
    });
  }

  onWatchAsset() {
    // this.router.navigateByUrl('/places/tabs/discover');
    // this.navCtrl.navigateBack('/places/tabs/discover');
    // this.navCtrl.pop();
   /* this.modalCtrl
      .create({
        component: CreateWatchComponent,
        componentProps: { selectedAsset: this.asset }
      })
      .then(modalEl => {
        modalEl.present();
        return modalEl.onDidDismiss();
      })
      .then(resultData => {
        console.log(resultData.data, resultData.role);
        if (resultData.role === 'confirm') {
          console.log('Watched!');
        }
      });
  } */
  this.actionSheetCtrl
      .create({
        header: 'Choose an Action',
        buttons: [
          {
            text: 'Schedule maintenance',
            handler: () => {
              this.openBookingModal('maintenance');
            }
          },
          {
            text: 'Decommission Asset',
            handler: () => {
              this.openBookingModal('decoms');
            }
          },
          {
            text: 'Monitor Asset',
            handler: () => {
              this.openBookingModal('monitor');
            }
          },
          {
            text: 'Cancel',
            role: 'cancel'
          }
        ]
      })
      .then(actionSheetEl => {
        actionSheetEl.present();
      });
  }

  openBookingModal(mode: 'maintenance' | 'decoms' | 'monitor') {
    console.log(mode);
    /* this.modalCtrl
      .create({
        component: CreateBookingComponent,
        componentProps: { selectedPlace: this.place, selectedMode: mode }
      })
      .then(modalEl => {
        modalEl.present();
        return modalEl.onDidDismiss();
      })
      .then(resultData => {
        console.log(resultData.data, resultData.role);
        if (resultData.role === 'confirm') {
          console.log('BOOKED!');
        }
      }); */
  }
}
