import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { IonicModule } from '@ionic/angular';

import { AssetsPage } from './assets.component';
import { AssetsRoutingModule } from './assets-routing.module';

@NgModule({
  imports: [
    CommonModule,
    IonicModule,
    AssetsRoutingModule
  ],
  declarations: [AssetsPage]
})
export class AssetsPageModule {}
