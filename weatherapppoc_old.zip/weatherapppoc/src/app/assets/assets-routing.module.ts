import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AssetsPage } from './assets.component';

const routes: Routes = [
  {
    path: 'tabs',
    component: AssetsPage,
    children: [
      {
        path: 'search',
        children: [
          {
            path: '',
            loadChildren: './search/search.module#SearchPageModule'
          },
          {
            path: ':assetId',
            loadChildren:
              './search/asset-detail/asset-detail.module#AssetDetailPageModule'
          }
        ]
      },
     {
        path: 'manage',
        children: [
          {
            path: '',
            loadChildren: './manage/manage.module#ManagePageModule'
          },
          {
            path: 'new',
            loadChildren:
              './manage/new-asset/new-asset.module#NewAssetPageModule'
          },
          {
            path: 'edit/:assetId',
            loadChildren:
              './manage/edit-asset/edit-asset.module#EditAssetPageModule'
          }
        ]
      },
      {
        path: '',
        redirectTo: '/assets/tabs/search',
        pathMatch: 'full'
      }
    ]
  },
  {
    path: '',
    redirectTo: '/assets/tabs/search',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AssetsRoutingModule {}
