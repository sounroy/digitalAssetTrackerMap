import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assets',
  templateUrl: './assets.component.html',
  styleUrls: ['./assets.scss'],
})
export class AssetsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
