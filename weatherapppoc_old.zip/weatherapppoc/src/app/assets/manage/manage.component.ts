import { Component, OnInit } from '@angular/core';

import { AssetsService } from '../assets.service';
import { Asset } from '../asset.model';
import { IonItemSliding } from '@ionic/angular';
import { Router } from '@angular/router';

@Component({
  selector: 'app-manage',
  templateUrl: './manage.component.html',
  styleUrls: ['./manage.scss'],
})
export class ManagePage implements OnInit {
  assets: Asset[];

  constructor(private assetService: AssetsService, private router: Router) { }

  ngOnInit() {
    this.assets = this.assetService.assets;
  }


  onEdit(assetId: string, slidingItem: IonItemSliding) {
    slidingItem.close();
    this.router.navigate(['/', 'assets', 'tabs', 'manage', 'edit', assetId]);
    console.log('Editing item', assetId);
  }
}
