import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NavController } from '@ionic/angular';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AssetsService } from '../../assets.service';
import { Asset } from '../../asset.model';

@Component({
  selector: 'app-edit-asset',
  templateUrl: './edit-asset.component.html',
  styleUrls: ['./edit-asset.scss']
})
export class EditAssetPage implements OnInit {
  asset: Asset;
  form: FormGroup;
  
  constructor(
    private route: ActivatedRoute,
    private assetsService: AssetsService,
    private navCtrl: NavController
  ) {}

  ngOnInit() {
    this.route.paramMap.subscribe(paramMap => {
      if (!paramMap.has('assetId')) {
        this.navCtrl.navigateBack('/assets/tabs/manage');
        return;
      }
      this.asset = this.assetsService.getAsset(paramMap.get('assetId'));
      this.form = new FormGroup({
        title: new FormControl(this.asset.title, {
          updateOn: 'blur',
          validators: [Validators.required]
        }),
        description: new FormControl(this.asset.description, {
          updateOn: 'blur',
          validators: [Validators.required, Validators.maxLength(180)]
        })
      });
    });
  }

  onUpdateAssetClick() {
    if (!this.form.valid) {
      return;
    }
    console.log(this.form);
  }
}
